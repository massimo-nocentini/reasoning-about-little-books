let ws = ["The"; "key"; "observation"; "is"; "that"; "in"; "the"; 
     "optimal"; "formatting"; "of"; "a"; "paragraph"; "of"; 
     "text,"; "the"; "formatting"; "of"; "the"; "text"; "past";
     "any"; "given"; "point"]

let wl = ["The"; "key"; "observation"; "is"; "that"; "in"; "the"; 
     "optimal"; "formatting"; "of"; "a"; "paragraph"; "of"; 
     "text,"; "the"; "formatting"; "of"; "the"; "text"; "past"; 
     "any"; "given"; "point"; "is"; "the"; "optimal"; "formatting";
     "of"; "just"; "that"; "text,"; "given"; "that"; "its"; "first";
     "character"; "starts"; "at"; "the"; "column"; "position"; 
     "where"; "the"; "prior"; "formatted"; "text"; "ends."; "Thus,";
     "the"; "formatting"; "problem"; "has"; "optimal"; "substructure"; 
     "when"; "cast"; "in"; "this"; "way."]
